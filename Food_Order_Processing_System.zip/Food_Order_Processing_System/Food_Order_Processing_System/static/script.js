
document.addEventListener("DOMContentLoaded", function () {
    const orderForm = document.getElementById("orderForm");
    const quantityInputs = document.querySelectorAll(".quantity-input");
    const grandTotalElement = document.getElementById("grandTotal");
    const itemCountElement = document.getElementById("itemCount");
    const placeOrderBtn = document.getElementById("placeOrderBtn");

    // Calculate the total amount whenever a quantity changes.
    function calculateTotal() {
        let grandTotal = 0;
        let totalItems = 0;

        quantityInputs.forEach(function (input) {
            const price = Number(input.dataset.price) || 0;
            let quantity = Number(input.value) || 0;

            // Keep quantity within the allowed range.
            if (quantity < 0) {
                quantity = 0;
                input.value = 0;
            }

            if (quantity > 100) {
                quantity = 100;
                input.value = 100;
            }

            const subtotal = price * quantity;
            grandTotal += subtotal;
            totalItems += quantity;

            const orderItem = input.closest(".order-item");
            const subtotalElement = orderItem
                ? orderItem.querySelector(".subtotal-value")
                : null;

            if (subtotalElement) {
                subtotalElement.textContent = subtotal.toLocaleString(
                    "en-IN"
                );
            }
        });

        if (grandTotalElement) {
            grandTotalElement.textContent = grandTotal.toLocaleString(
                "en-IN"
            );
        }

        if (itemCountElement) {
            itemCountElement.textContent =
                totalItems + (totalItems === 1 ? " item selected" : " items selected");
        }

        if (placeOrderBtn) {
            placeOrderBtn.disabled = totalItems === 0;
            placeOrderBtn.style.opacity = totalItems === 0 ? "0.6" : "1";
            placeOrderBtn.style.cursor =
                totalItems === 0 ? "not-allowed" : "pointer";
        }
    }

    quantityInputs.forEach(function (input) {
        input.addEventListener("input", calculateTotal);
        input.addEventListener("change", calculateTotal);
    });

    // Confirm the order before submitting the form.
    if (orderForm) {
        orderForm.addEventListener("submit", function (event) {
            const nameInput = document.getElementById("customer_name");
            const phoneInput = document.getElementById("phone");

            const customerName = nameInput ? nameInput.value.trim() : "";
            const phone = phoneInput ? phoneInput.value.trim() : "";

            let totalItems = 0;

            quantityInputs.forEach(function (input) {
                const quantity = Number(input.value) || 0;

                if (
                    !Number.isInteger(quantity) ||
                    quantity < 0 ||
                    quantity > 100
                ) {
                    totalItems = 0;
                    input.setCustomValidity(
                        "Quantity must be a whole number between 0 and 100."
                    );
                } else {
                    input.setCustomValidity("");
                    totalItems += quantity;
                }
            });

            if (!customerName || !phone) {
                return;
            }

            if (!/^[0-9]{10}$/.test(phone)) {
                event.preventDefault();
                alert("Please enter a valid 10-digit phone number.");
                return;
            }

            if (totalItems === 0) {
                event.preventDefault();
                alert("Please select at least one food item.");
                return;
            }

            const confirmed = window.confirm(
                "Confirm your food order?\n\n" +
                "Customer: " + customerName + "\n" +
                "Total items: " + totalItems + "\n" +
                "Total amount: ₹" +
                (grandTotalElement ? grandTotalElement.textContent : "0")
            );

            if (!confirmed) {
                event.preventDefault();
            }
        });
    }

    // Confirmation for order-status update buttons.
    document.querySelectorAll("form[data-confirm]").forEach(function (form) {
        form.addEventListener("submit", function (event) {
            const message = form.dataset.confirm;

            if (message && !window.confirm(message)) {
                event.preventDefault();
            }
        });
    });

    // Initial calculation when the page loads.
    calculateTotal();
});
